<?php 

include('vendor/autoload.php');


$name = $_POST['name'];
$fname = $_POST['fname'];
$age = $_POST['age'];


$app_id = '1102299';
$app_key = '531de518d38b0d7807b3';
$app_secret = '96ba299712b44a821fbf';
$app_cluster = 'ap2';

$pusher = new Pusher\Pusher( $app_key, $app_secret, $app_id, array('cluster' => $app_cluster) );

$data['message'] = array(
    'student_name' => $name,
    'student_father' => $fname,
    'age' => $age
);

$pusher->trigger( 'pusher_demo1', 'add_student', $data );
echo '<h1>Student Added Successfully</h1>';


?>