<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 mt-5">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Students List</h5>
                        <table class="table table-hover">
                            <thead>
                                <th>Student Name</th>
                                <th>Father Name</th>
                                <th>Age</th>
                            </thead> 
                            <tbody id="students">

                            </tbody>                       
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>

// Enable pusher logging - don't include this in production
Pusher.logToConsole = true;

var pusher = new Pusher('531de518d38b0d7807b3', {
  cluster: 'ap2'
});

var channel = pusher.subscribe('pusher_demo1');
channel.bind('add_student', function(data) {
  var sname = data['message']['student_name'];
  var fname = data['message']['student_father'];
  var age = data['message']['age'];
  var tr;
  tr +='<tr>';
  tr +='<td>';
  tr += sname;
  tr +='</td>';
  tr +='<td>';
  tr += fname;
  tr +='</td>';
  tr +='<td>';
  tr += age;
  tr +='</td>';
  tr +='</tr>';

$('#students').append(tr);

});
</script>
</body>
</html>