<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="update.css">
    <link rel="stylesheet" href="/PHPMailer/Exception.php">
    <title>Thanks</title>
    <style>
        body{
            background:  #fdf1ec;
        }
    </style>
</head>
<body>


<div class="login-page">
    <h1>Thank you for your Email!</h1>
  </div>
</div>

</body>
</html>