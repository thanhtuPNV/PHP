<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background-image: url(//chaitan.like-themes.com/wp-content/uploads/2018/07/inner-bg-cut.jpg);
            background-size: cover;
            background-position: center;
            height: 61vh;
            background-attachment: fixed;
        }
    </style>
</head>

<body>
    <?php
    require_once "./mvc/views/pages/" . $data["page"] . ".php";
    ?>
</body>

</html>