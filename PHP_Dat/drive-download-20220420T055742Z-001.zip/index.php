<?php 
    require_once "./mvc/views/bridge.php";
    
    $myAPP = new App();
?>