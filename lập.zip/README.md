# MyLiShop with database

1. Homepage
![homepageMyLiShop](https://user-images.githubusercontent.com/89339440/160519203-a3700468-47b7-4bc6-948d-f9411ff62627.png)

2. Register 
![register](https://user-images.githubusercontent.com/89339440/160519315-24ddcc73-c0c2-48c5-aacf-7817a121fb17.PNG)

3. Detail page

![detailpage](https://user-images.githubusercontent.com/89339440/160519251-74b6cbcd-4c7f-467f-9eb0-c662f0bf0bc5.png)

4. Cart page
 
![cart](https://user-images.githubusercontent.com/89339440/160519433-d7d18110-91e3-4382-a20e-c0f32e12a714.PNG)

5. Edit cart

![editcart](https://user-images.githubusercontent.com/89339440/160519457-23c7e47f-312f-4dc5-9fbb-01ac03aabffc.png)

- Create the Database with the name ABC... -> import the MyLiShop_Database.sql file
- Open the dbConnect.php file into php folder -> and rename the $database variable into ABC...
- Run the index.php file.

